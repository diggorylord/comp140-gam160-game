# comp140-gam160-game
Repository for Assignment 1 of COMP140-GAM160

Game Idea: Diggory Lord:

The idea for my game is a basic runner type game where you will be,
in this case, driving, rather than running, but you wll be moving 
along courses, like levels in a way. At the end of each course is
an item you have to collect, in this case its a petrol can or car charger
depending on the level whether its futuristic or more like most places
of today with petrol cars. The way that the game will run is by adding 
a continual force on the player so they can only choose to go faster
or slower by using the corresponding input as with the left and right 
input for turning the player. The play style will be aimed at using a
different control set that focuses on the movement controls and the gravity
mechanics. These inputs will be what activate the speed of movement as well 
as control when the player would use the gravity pickup.

There would be a twist. You would have parts of the track that require a 
swap of gravity. In other words, you have to go upside down on the	
track to carry on. However this gravity mechanic requires the use of	
a pickup that you need to have to use gravity. This mechanic would work
by using the physics engine in unity to control forces on the player
to then change them when the player has a pickup to change the gravity
when the time arises. It would use forces to add gravity to the player
and when the pickup has been collected, an input wil decide the gravity
the player has meaning that the player can move on the ceiling rather 
than the floor.

There will be other collectibles in the levels, each themed with a 
car related object. This could be a sterring wheel or an engine or
a headlight. All of these would give points and they would be placed at
intervals in each level, aiming to get the player to go for them
for a high score. However there would be one bad collectible which will
not only reduce your score but will also set you back to the begining of
the level itself. This might be something like oil or black ice for example.

During each level, depending on the type of level it is, there will 
be obstacles that will try to hinder you or reset your position. These
would be things like lasers in the futuristic levels and falling buildings
or boulders in the more present time levels. Each of these hindrances will
do certain things depending on what level type it is. For example on the
futuristic level, th lasers could send you bak to the beginning of the level.
Then the boulders or faling buildings could block your path so you would
have to be quick getting past them or you would have to make sure you
pick up a gravity collectible to reverse gravity in order to get past it.
